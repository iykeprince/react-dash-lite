<?php
define('APP_JWT_SECRET', '!@#$%@#$@#4app_tradinary_secret23@!#$!');
