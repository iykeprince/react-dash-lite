<?php
class Receiver{
	public $id;
	public $user_id;
	public $level;
	public $date_gh;
	public $time_gh;
	public $amount_to_receive;
	public $amount_received=0; 
	public $those_to_pay_me ="";
}